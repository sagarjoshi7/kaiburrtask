## Project has been made with Jersey
Created Java Rest-API using Jersey framework.

### Requirements:
- Apache Tomcat EE plus
- Jersey 2.30
- Eclipse

For url's used in the project, go to:
> http://localhost:8082/KaiburrTask1/index.html/

_Current Error's in the project:
On adding new server object, the previous object gets deleted instead of creation of new object._

> 16BIS0178
